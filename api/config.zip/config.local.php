<?php
declare(strict_types=1);

return [
    'host' => 'localhost',
    'port' => '3306',
    'name' => 'gimhana_portfolio',
    'user' => 'root',
    'password' => '',
];
