<?php
declare(strict_types=1);

return [
    'host' => 'localhost',
    'port' => '3306',
    'name' => 'sudessca_gimhana_portfolio',
    'user' => 'sudessca_evonGimhana',
    'password' => '4qGeCWrmPV1e',
];
